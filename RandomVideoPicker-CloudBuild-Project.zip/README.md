# Random Video Picker

This version scans videos visible in your Android gallery and plays a random one full-screen. It includes a GitHub Actions workflow so you can build the APK in the cloud without installing Android Studio.

## Build the APK without Android Studio
1. Download and extract this ZIP.
2. Create a GitHub repository at https://github.com/new.
3. Upload the extracted project files to the repository (including the hidden `.github` folder).
4. Open the repository's **Actions** tab and choose **Build Android APK**. Click **Run workflow** if it is not already running.
5. When the workflow completes, open the run and download the **RandomVideoPicker-APK** artifact.
6. Extract that downloaded artifact ZIP on your phone and tap `app-debug.apk` to install it. Android may ask you to allow installation from your browser or file manager.

The app requests permission to read videos in the gallery. It does not upload or share your videos. This is a debug APK, not a Play Store release.
