package com.example.randomvideopicker

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView

class MainActivity : Activity() {
    private val videos = mutableListOf<Uri>()
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private var videoView: VideoView? = null
    private var playing = false
    private val permissionCode = 10

    private fun requiredPermission(): String = if (Build.VERSION.SDK_INT >= 33) {
        Manifest.permission.READ_MEDIA_VIDEO
    } else {
        Manifest.permission.READ_EXTERNAL_STORAGE
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(requiredPermission()) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(requiredPermission()), permissionCode)
        } else {
            scanVideos()
        }
    }

    private fun showHome() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 28, 24, 28)
            setBackgroundColor(Color.rgb(248, 249, 252))
        }
        val title = TextView(this).apply {
            text = "Random Video Picker"
            textSize = 28f
            setTextColor(Color.rgb(25, 35, 55))
            gravity = Gravity.CENTER
        }
        root.addView(title, params())
        status = TextView(this).apply {
            text = "Checking your gallery for videos…"
            textSize = 16f
            setTextColor(Color.rgb(70, 78, 92))
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 18)
        }
        root.addView(status, params())
        root.addView(Button(this).apply {
            text = "Refresh Gallery"
            setOnClickListener { scanVideos() }
        }, params())
        root.addView(Button(this).apply {
            text = "Play Random Video Full-Screen"
            setOnClickListener { playRandom() }
        }, params())
        root.addView(Button(this).apply {
            text = "Pick Another Video"
            setOnClickListener { playRandom() }
        }, params())
        val note = TextView(this).apply {
            text = "Picks from videos visible to this app. Your videos stay on your phone."
            textSize = 13f
            setTextColor(Color.GRAY)
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 0)
        }
        root.addView(note, params())
        setContentView(root)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            scanVideos()
        } else if (requestCode == permissionCode) {
            status.text = "Video access is needed to pick randomly from your gallery. Allow it in app permissions."
        }
    }

    private fun scanVideos() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(requiredPermission()) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(requiredPermission()), permissionCode)
            return
        }
        videos.clear()
        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Video.Media._ID)
        val sort = "${MediaStore.Video.Media.DATE_ADDED} DESC"
        var cursor: Cursor? = null
        try {
            cursor = contentResolver.query(collection, projection, null, null, sort)
            cursor?.use {
                val idIndex = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                while (it.moveToNext()) {
                    val id = it.getLong(idIndex)
                    videos.add(ContentUris.withAppendedId(collection, id))
                }
            }
            status.text = if (videos.isEmpty()) "No videos found. Add videos to your gallery, then tap Refresh Gallery." else "Found ${videos.size} video(s) in your gallery. Tap Play Random Video!"
        } catch (_: Exception) {
            status.text = "Could not read the gallery. Check video access in Android settings."
        }
    }

    private fun playRandom() {
        if (videos.isEmpty()) {
            scanVideos()
            if (videos.isEmpty()) {
                Toast.makeText(this, "No gallery videos found yet.", Toast.LENGTH_SHORT).show()
                return
            }
        }
        val uri = videos.random()
        playing = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
        val player = VideoView(this)
        videoView = player
        player.setBackgroundColor(Color.BLACK)
        val frame = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(player, FrameLayout.LayoutParams(-1, -1))
            addView(Button(this@MainActivity).apply {
                text = "✕"
                textSize = 20f
                setOnClickListener { stopPlayback() }
            }, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.END))
        }
        setContentView(frame)
        player.setVideoURI(uri)
        player.setOnPreparedListener { mediaPlayer ->
            mediaPlayer.isLooping = false
            player.start()
        }
        player.setOnCompletionListener { playRandom() }
        player.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "This video could not be played.", Toast.LENGTH_SHORT).show()
            stopPlayback()
            true
        }
    }

    private fun stopPlayback() {
        playing = false
        videoView?.stopPlayback()
        videoView = null
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
        showHome()
        status.text = "Found ${videos.size} video(s) in your gallery. Tap Play Random Video!"
    }

    @Deprecated("Activity is recreated only by the system; preserve home view when backing out of playback")
    override fun onBackPressed() {
        if (playing) stopPlayback() else super.onBackPressed()
    }

    private fun params() = LinearLayout.LayoutParams(-1, -2).apply {
        topMargin = 6
        bottomMargin = 6
    }
}
